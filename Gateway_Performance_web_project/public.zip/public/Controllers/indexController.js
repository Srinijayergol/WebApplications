var app = angular.module('myGatewayApp',['ngRoute']);
app.controller('myGatewayController',function ($scope, $http,$timeout) {
    $scope.dataValues = new Array;
    $scope.loadValues = function(){
       $http.get('/Controllers/json_Data.json').then(function(jsonData) {
            $scope.dataValues = jsonData;
            $scope.list = $scope.dataValues;
            console.log($scope.list.data);
            }).catch(function (Object) {
                 alert(Object.data);
            });
    $timeout(function(){
      $scope.loadValues();
    },3000)
  };
    $scope.loadValues();
});
